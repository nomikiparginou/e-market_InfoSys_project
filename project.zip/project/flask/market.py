#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
from flask import Flask, request, jsonify, redirect, Response
from bson.objectid import ObjectId
import json
import uuid
import time

#connect to our local MongoDB
client = MongoClient('mongodb://localhost:27017/')

#choose database
db = client['DSMarket']

#choose collections
users = db['Users']
products = db['Products']

#initiate Flask App
app = Flask(__name__)

users_sessions = {}
admin_sessions = {}

def create_user_session(email):
    user_uuid = str(uuid.uuid1())
    users_sessions[user_uuid] = (email, time.time())
    return user_uuid  

def is_user_session_valid(user_uuid):
    return user_uuid in users_sessions

def create_admin_session(email):
    admin_uuid = str(uuid.uuid1())
    admin_sessions[admin_uuid] = (email, time.time())
    return admin_uuid  

def is_admin_session_valid(admin_uuid):
    return admin_uuid in admin_sessions


#Endpoint 1: Login
@app.route('/login', methods=['POST'])
def login():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "email" in data or not "password" in data:
        return Response("Incomplete credentials",status=500,mimetype="application/json")

    user = users.find_one({"email":data['email']})
    if user == None:
        return Response('No user found with that email' ,status=500,mimetype='application/json')
    if user['password'] == data['password']:
        if user['category'] == "admin":
            user_uuid = create_admin_session(user['email'])
            res = {"uuid": user_uuid, "email": user['email']}
            return Response(res['email']+", you have successfully logged in as an admin!\nYour session ID: "+res['uuid'],status=200, mimetype='application/json')
        else: 
            user_uuid = create_user_session(user['email'])
            res = {"uuid": user_uuid, "email": user['email']}
            return Response(res['email']+", you have successfully logged in as a simple user!\nYour session ID: "+res['uuid'],status=200, mimetype='application/json')
    else:
        return Response("Wrong password.", status=400, mimetype='application/json')


#Endpoint 2: Sign Up for simple user
@app.route('/SignUp', methods=['POST'])
def create_user():
    #request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "username" in data or not "email" in data or not "password":
        return Response("Incomplete Credentials",status=500,mimetype="application/json")

    if users.find({"email":data["email"]}).count() == 0:
        
        user = {"username": data['username'], "email":['email'], "password":data['password']}
        
        users.insert_one(user)
        data.update({'category':'simple user'})
        users.insert_one(data)
        
        return Response(data['username']+" was added to the DS Market", status=200, mimetype='application/json')
    else:
        
     return Response("A user with the given username already exists", status=401, mimetype='application/json')

#Endpoint 3: Add Product
@app.route('/addProduct', methods=['POST'])
def add_product():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "name" in data or not "category" in data or not "stock" in data or not "description" in data or not "price" in data:
        return Response("Product information incomplete",status=500,mimetype="application/json")

    uuid = request.headers.get('authorization')
    auth = is_admin_session_valid(uuid)
    if auth == False:
        return Response('Admin was not authorized', status=401, mimetype="application/json")
    else:
        product = {"name":data['name'], "category":data['category'], "stock":data['stock'], "description":data['description'], "price":data['price']}
        products.insert_one(product)
        return Response(data['name']+" was added to the Products Collection", status=200,mimetype='application/json')

#Endpoint 4: Delete Product
@app.route('/deleteProduct', methods=['DELETE'])
def delete_product():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "_id" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")

    uuid = request.headers.get('authorization')
    auth = is_admin_session_valid(uuid)
    if auth == False:
        return Response('Admin was not authorized', status=500, mimetype="application/json")
    else:
        product = products.find_one({"_id": ObjectId(data['_id'])})
        if product:
            msg = "Product with id: "+str(product['_id'])+" was deleted from the database."
            products.delete_one({"_id": ObjectId(product['_id'])})
            status=200
        else:
            pid = {"_id":data['_id']}
            msg = "No product with id: " + pid
            status=500
        return Response(msg,status,mimetype="application/json")

#Endpoint 5: Update Product
@app.route('/updateProduct', methods=['PATCH'])
def update_product():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "_id" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")

    uuid = request.headers.get('authorization')
    auth = is_admin_session_valid(uuid)
    if auth == False:
        return Response('Admin was not authorized', status=500, mimetype="application/json")
    else:
        product = products.find_one({"_id": ObjectId(data['_id'])})
        if product:
            if "name" in data:
                products.update_one({"_id":ObjectId(data['_id'])},{"$set": {"name":data['name']}})
            if "price" in data:
                products.update_one({"_id":ObjectId(data['_id'])},{"$set": {"price":data['price']}})
            if "stock" in data:
                products.update_one({"_id":ObjectId(data['_id'])},{"$set": {"stock":data['stock']}})
            if "description" in data:
                products.update_one({"_id":ObjectId(data['_id'])},{"$set": {"description":data['description']}})
            product = products.find_one({"_id": ObjectId(data['_id'])})
            product['_id'] = None
            return Response("Product with id: "+str(product['_id'])+" was updated successfully\nNew product info:\n"+json.dumps(product,indent=4),status=200,mimetype="application/json")    
        else:
            pid = {"_id":data['_id']}
            msg = "No product with id: " + pid
            return Response(msg,status=500,mimetype="application/json")
     

#Endpoint 7: Delete User  
@app.route('/deleteUser', methods=['DELETE'])
def delete_user():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "password" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")

    uuid = request.headers.get('authorization')
    auth = is_user_session_valid(uuid)
    if auth == False:
        return Response('User was not authorized', status=500, mimetype="application/json")
    else:
        user1 = users_sessions.get(uuid)
        email = user1[0]
        user = users.find_one({"email":email})       
        if data["password"] == user["password"]:
            msg = "User "+user['username']+" was deleted from the DSMarket database."
            users.delete_one({"email":user['email']})
            status=200
        else:
            email = {"email":data['email']}
            msg = "Incorrect password" +data['data']
            status=500
        return Response(msg,status,mimetype="application/json")

#Endpoint 8: Product Search  
@app.route('/searchProduct', methods=['GET'])
def search_prod():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')

    uuid = request.headers.get('authorization')
    auth = is_user_session_valid(uuid)
    if auth == False:
        return Response('User was not authorized', status=500, mimetype="application/json")
    else:
        if "name" in data:
            product_list = products.find({"name":data['name']})
        elif "category" in data:
            product_list = products.find({"category":data['category']})
        elif "id" in data:
            product_list = products.find({"_id":ObjectId(data['id'])})
        else:
            return Response("Information incomplete",status=500,mimetype="application/json")
    
    if product_list:
        result="Results: \n"
        for product in product_list:
            result += "\nid: "+str(product.get('_id'))
            result += "\nname: "+str(product.get('name'))
            result += "\ndescription: "+str(product.get('description'))
            result += "\nprice: "+str(product.get('price'))
            result += "\ncategory: "+str(product.get('category'))+"\n"
        return Response(result, status=200, mimetype="application/json")
    else:
        return Response("No product result for that search", status=500, mimetype="application/json")


#Endpoint 9: Add products to cart
@app.route('/addToCart', methods=['PATCH'])
def add_products():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "product" in data or not "quantity" in data:
        return Response("Information incomplete",status=500,mimetype='application/json')

    uuid = request.headers.get('authorization')
    auth = is_user_session_valid(uuid)
    if auth == False:
        return Response('User has not logged in', status=401, mimetype='application/json')
    else:
        user1 = users_sessions.get(uuid)
        email = user1[0]
        user = users.find_one({"email":email})       
        product = products.find_one({"_id": ObjectId(data['product'])})
        quantity = int(data['quantity'])
        if product:
            if int(product['stock']) >= quantity:
                if "cart" in user:
                    if user['cart'] != None:
                        cart1 =  user['cart']
                        cart1.update({data["product"]:data["quantity"]})
                        users.update_one({"email":email},{'$set':{"cart": cart1}})
                    else:
                        users.update_one({"email":user['email']},{'$set': {'cart': {data['product']: data['quantity']}}}) 
                else:
                    users.update_one({"email":user['email']},{'$set': {'cart': {data['product']: data['quantity']}}}) 
                    #products.update_one({"_id": ObjectId(data['product'])}, { '$inc': {"stock": int("-"+data['quantity']) }})
                
                msg = "The product "+product['name']+" was added to your cart\nYour Cart:\n"
                user = users.find_one({"email":email}) 
                cart1 =  user['cart']
                cartCost = 0
                for prodID in cart1:
                    product = products.find_one({"_id":ObjectId(prodID)})
                    name = product["name"]
                    price = product["price"]
                    quantity = cart1[prodID]
                    msg += name+" x "+str(quantity)+"\n"
                    cartCost += float(price)*float(quantity)
                msg += "total cost: "+str(cartCost)
                status=200
            else:
                msg = "Product stock is less than the given quantity" 
                status=500       
        else:
            msg = "No product with that id"
            status=500
        return Response(msg, status, mimetype='application/json')

#Endpoint 10: Show Cart  
@app.route('/showCart', methods=['GET'])
def show_cart():
    
    uuid = request.headers.get('authorization')
    auth = is_user_session_valid(uuid)
    if auth == False:
        return Response('User was not authorized', status=500, mimetype="application/json")
    else:
        user1 = users_sessions.get(uuid)
        email = user1[0]
        user = users.find_one({"email":email})   
        if "cart" in user: 
            if user["cart"] != None:
                cart1 =  user['cart']
                cartCost = 0
                msg = "Your Cart: \n"
                for prodID in cart1:
                    product = products.find_one({"_id":ObjectId(prodID)})
                    name = product["name"]
                    price = product["price"]
                    quantity = cart1[prodID]
                    msg += name+" x "+str(quantity)+"\t"+str(price)+" euro\n"
                    cartCost += float(price)*float(quantity)
                status=200
                msg+= "Total Cost: "+str(cartCost)
            else:
                msg="Your Cart is empty"
                status = 500
        else:
            msg = "Your cart is empty!"
            status=500
        return Response(msg, status, mimetype='application/json')

#Endpoint 11: Delete Product from Cart  
@app.route('/deleteFromCart', methods=['DELETE'])
def delete_from_cart():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "id" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")

    uuid = request.headers.get('authorization')
    auth = is_user_session_valid(uuid)
    if auth == False:
        return Response('User was not authorized', status=500, mimetype="application/json")
    else:
        user1 = users_sessions.get(uuid)
        email = user1[0]
        user = users.find_one({"email":email}) 
        if "cart" in user:
            cart = user['cart']
            if user["cart"] != None:
                for prodID in cart:
                    if prodID == data["id"]:
                        del cart[data["id"]]
                        users.update_one({"email":email},{'$set':{"cart": cart}})
                        msg = "Product "+data["id"]+" has been removed from your cart"
                        status=200
                        break
                    else:
                        msg = "No product with such id in your cart"
                        status=500
            else: 
                msg = "No products in your cart to remove"
        else:
            msg = "No products in your cart to remove"
            status = 500
        return Response(msg, status, mimetype='application/json')

#Endpoint 12: Place Order
@app.route('/placeOrder', methods=['PATCH'])
def place_order():
    # Request JSON data
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "card number" in data:
        return Response("Information incomplete",status=500,mimetype='application/json')

    uuid = request.headers.get('authorization')
    auth = is_user_session_valid(uuid)
    if auth == False:
        return Response('User has not logged in', status=401, mimetype='application/json')
    else:
        user1 = users_sessions.get(uuid)
        email = user1[0]
        user = users.find_one({"email":email})  
        if len(data["card number"]) == 16:
            if "cart" in user: 
                if user["cart"] != None:
                    cart1 =  user['cart']
                    cartCost = 0
                    msg = "Purchase receipt \n"
                    for prodID in cart1:
                        product = products.find_one({"_id":ObjectId(prodID)})
                        name = product["name"]
                        price = product["price"]
                        quantity = cart1[prodID]
                        leftStock = int(product["stock"]) - int(quantity)
                        msg += name+" x "+str(quantity)+"\t"+str(price)+" euro\n"
                        cartCost += float(price)*float(quantity)
                        products.update_one({"_id": ObjectId(product['_id'])}, { '$set': {"stock": str(leftStock)}})
                    msg += "Total Cost: "+str(cartCost)
                    users.update_one({"email":email},{'$set':{"cart": None}})
                    if "orderHistory" in user:
                        history = user["orderHistory"]                        
                        history.update(cart1)
                        users.update_one({"email":email},{'$set':{"orderHistory": history}})
                    else:
                        users.update_one({"email":email},{'$set':{"orderHistory": cart1}})

                    return Response(msg, status=200,mimetype="application/json" )
                else:
                    return Response("No items in your cart to purchase!",  status=500, mimetype="application/json")
            else:
                return Response("No items in your cart to purchase!",  status=500, mimetype="application/json")
        else:
            return Response("Card number was entered incorrectly",  status=400, mimetype="application/json")

#Endpoint 13: Show order history 
@app.route('/orderHistory', methods=['GET'])
def order_history():

    uuid = request.headers.get('authorization')
    auth = is_user_session_valid(uuid)
    if auth == False:
        return Response('User was not authorized', status=500, mimetype="application/json")
    else:
        user1 = users_sessions.get(uuid)
        email = user1[0]
        user = users.find_one({"email":email})
        if "orderHistory" in user:
            msg = "Your order history: \n"
            history = user["orderHistory"]
            for prodID in history:
                product = products.find_one({"_id":ObjectId(prodID)})
                msg += product["name"] +" x "+history[prodID]+"\n"

            return Response(msg, status=200,mimetype="application/json" )
        
        else:
            return Response("You have no order history", status=200,mimetype="application/json" )

#Endpoint 11: Delete Product from Cart  
@app.route('/deleteCart', methods=['DELETE'])
def delete_cart():
    data = None 
    try:
        data = json.loads(request.data)
    except Exception as e:
        return Response("bad json content",status=500,mimetype='application/json')
    if data == None:
        return Response("bad request",status=500,mimetype='application/json')
    if not "email" in data:
        return Response("Information incomplete",status=500,mimetype="application/json")

    users.update_one({"email":data["email"]},{'$set':{"cart": None}})
    return Response("Cart empty",  status=200, mimetype="application/json")


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
