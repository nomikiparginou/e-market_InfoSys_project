import json, os, sys
from pymongo import MongoClient

mongodb_hostname = os.environ.get("MONGO_HOSTNAME","localhost")
client = MongoClient('mongodb://'+mongodb_hostname+':27017/')

# Choose DSMarket database
db = client['DSMarket']
users = db['Users']
products = db['Products']

def insert(entry, file):
    try:
        if file == "./data/users.json":
            users.insert_one(entry)
            return True 
        else: 
            products.insert_one(entry)
            return True
    except Exception as e:
        print(e)
        return False 

def insert_all(file):
    file = open(file,'r')
    lines = file.readlines()
    for line in lines:
        entry = None 
        try:
            entry = json.loads(line)
        except Exception as e:
            print(e)
            continue
        if entry != None:
            entry.pop("_id",None) 
            insert(entry, file)

insert_all("./data/users.json")
insert_all("./data/products.json")